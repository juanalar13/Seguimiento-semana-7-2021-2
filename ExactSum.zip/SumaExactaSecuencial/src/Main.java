// 11057 - Exact Sum
// Secuential Search
// By Juan Felipe Alarcon

import java.util.ArrayList;
import java.util.Scanner;
 
class Main {		
	
	static int n;	
	static ArrayList<Integer> precios;
	static int dinero;
	
	public static int busquedaSecuencial(int L, int R, int T) {
		for(int i = L; i<=R; i++) {
			if (precios.get(i) == T) {
				return i;
			}
		}
		return -1;			        
	}
	
	
    public static void main(String[] args) {   	
    	
    	    	
    	System.out.printf("Exact Sum with Secuential Search, playing...\n\n");
        Scanner lector = new Scanner(System.in);
        while (lector.hasNext()) {
            n = lector.nextInt();			
            precios = new ArrayList<Integer>();
            for (int i = 0; i < n; i++) {
            	precios.add(lector.nextInt());
            }            	
            precios.sort(null);
            int dinero = lector.nextInt();
            int precio1 = -1;
            int precio2 = 1000001;
            long inicio = System.currentTimeMillis();
            for (int i = 0; i < n; i++) {
                int precioABuscar = dinero - precios.get(i);
                int resultado = busquedaSecuencial(i+1, n-1, precioABuscar);
                if (resultado >= 0 && Math.abs(precios.get(resultado) - precios.get(i)) < Math.abs(precio2 - precio1))
                {
                    precio1 = precios.get(i);
                    precio2 = precios.get(resultado);
                }
            }
            long fin = System.currentTimeMillis();
            if(precio1!=-1) {
            	System.out.printf("Peter should buy books whose prices are %d and %d, [time = %f].\n\n", precio1, precio2, (fin-inicio)/1000.0);
            }else {
            	System.out.printf("Peter can't buy the 2 books that fit his money\n\n");
            }
        }
        lector.close();
        
    }
}
